var searchData=
[
  ['encontrarminimo_31',['encontrarMinimo',['../ArvoreBinariaDinamica_8h.html#a6e85326cc97da75fc2c7f84a3a5a6a7d',1,'ArvoreBinariaDinamica.c']]]
];
