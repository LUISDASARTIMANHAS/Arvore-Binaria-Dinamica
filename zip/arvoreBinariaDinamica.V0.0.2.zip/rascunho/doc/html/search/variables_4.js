var searchData=
[
  ['raiz_44',['raiz',['../structArvoreBinaria.html#a7c0296fff60dfd59f6c421315144026c',1,'ArvoreBinaria']]]
];
