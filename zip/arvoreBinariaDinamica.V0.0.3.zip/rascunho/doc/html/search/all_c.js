var searchData=
[
  ['tamanho_23',['tamanho',['../structArvoreBinaria.html#a08ff813d0c454661c757bec4f11dde82',1,'ArvoreBinaria']]]
];
