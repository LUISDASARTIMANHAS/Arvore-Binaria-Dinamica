var searchData=
[
  ['salvardadosnoarquivo_21',['salvarDadosNoArquivo',['../ArvoreBinariaDinamica_8h.html#a163f62e48520f21010e3d7b4686564c7',1,'ArvoreBinariaDinamica.c']]],
  ['string_22',['string',['../ArvoreBinariaDinamica_8h.html#a4783b702c90b53920aa8ce4f0fd72dcc',1,'ArvoreBinariaDinamica.h']]]
];
