var searchData=
[
  ['calculartempo_29',['calcularTempo',['../ArvoreBinariaDinamica_8h.html#abe61f02453485beec353880756a81bbc',1,'ArvoreBinariaDinamica.c']]],
  ['contarmatriculas_30',['contarMatriculas',['../ArvoreBinariaDinamica_8h.html#af3f616774c6e19677bf8c81db2778dff',1,'ArvoreBinariaDinamica.c']]]
];
