var searchData=
[
  ['lereinserirmatriculas_35',['lerEInserirMatriculas',['../ArvoreBinariaDinamica_8h.html#a274c59b814bb8644c7405758153d1248',1,'ArvoreBinariaDinamica.c']]],
  ['liberararvore_36',['liberarArvore',['../ArvoreBinariaDinamica_8h.html#a1410c535bef8eb449dbf175e67a56200',1,'ArvoreBinariaDinamica.c']]]
];
