var searchData=
[
  ['salvardadosnoarquivo_39',['salvarDadosNoArquivo',['../ArvoreBinariaDinamica_8h.html#a163f62e48520f21010e3d7b4686564c7',1,'ArvoreBinariaDinamica.c']]]
];
