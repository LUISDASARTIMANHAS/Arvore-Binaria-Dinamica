var searchData=
[
  ['processtime_46',['processTime',['../ArvoreBinariaDinamica_8h.html#a5f0d87c497d4d5ab6afc1d936e5d68bf',1,'ArvoreBinariaDinamica.h']]]
];
