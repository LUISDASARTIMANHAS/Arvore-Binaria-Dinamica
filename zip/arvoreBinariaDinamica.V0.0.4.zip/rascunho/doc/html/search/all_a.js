var searchData=
[
  ['raiz_19',['raiz',['../structArvoreBinaria.html#a7c0296fff60dfd59f6c421315144026c',1,'ArvoreBinaria']]],
  ['removerno_20',['removerNo',['../ArvoreBinariaDinamica_8h.html#a44a96b39b78c64b04e03bc1f08ce9648',1,'ArvoreBinariaDinamica.c']]]
];
