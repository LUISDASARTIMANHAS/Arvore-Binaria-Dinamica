var searchData=
[
  ['abrirarquivo_27',['abrirArquivo',['../ArvoreBinariaDinamica_8h.html#af03a0a6245bf64a6522e8afedf59b492',1,'ArvoreBinariaDinamica.c']]]
];
