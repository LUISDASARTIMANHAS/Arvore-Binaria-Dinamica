var searchData=
[
  ['matricula_14',['matricula',['../structNoArvore.html#a2d39aee1e66eb4489376fc859a14ce11',1,'NoArvore']]],
  ['menuprincipal_15',['menuPrincipal',['../ArvoreBinariaDinamica_8h.html#a5ed4f2c147d67747f15ff86efbda3017',1,'ArvoreBinariaDinamica.c']]]
];
